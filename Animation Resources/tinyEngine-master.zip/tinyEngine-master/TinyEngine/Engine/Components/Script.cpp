#include "Script.h"

namespace TEngine {

	Script::Script() :Component() {}

	void Script::Start() {}

	void Script::Update() {}

	Script::~Script() {}

}