#pragma once

namespace TEngine {
	class Physics
	{
	};

}