#pragma once

#ifdef __GLES__
#include "esUtil.h"
#else
#include "glad/glad.h"
#include "glUtil.h"
#endif 